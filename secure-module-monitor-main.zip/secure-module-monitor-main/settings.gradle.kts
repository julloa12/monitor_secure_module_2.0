rootProject.name = "secure-module-monitor"
