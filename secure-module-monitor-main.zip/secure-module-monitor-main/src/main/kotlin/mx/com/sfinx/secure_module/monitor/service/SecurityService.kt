package mx.com.sfinx.secure_module.monitor.service

interface SecurityService {
    fun isAuthenticated(): Boolean
}