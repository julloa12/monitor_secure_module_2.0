package mx.com.sfinx.secure_module.monitor

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class SecureModuleMonitorApplicationTests {

	@Test
	fun contextLoads() {
	}

}
